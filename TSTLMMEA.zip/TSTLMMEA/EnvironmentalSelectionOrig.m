function [Population,Fitness,D_Dec,D_Pop,net,genFlag] = EnvironmentalSelectionOrig(Population,N,Problem,params,net,genFlag)
% The environmental selection of SPEA2 based on objective space

%------------------------------- Copyright --------------------------------
% Copyright (c) 2024 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    [FrontNo,~] = NDSort(Population.objs,N);
    valid = FrontNo == 1;
    NDPop = Population(valid);
    temp1 = NDPop.decs;
    gen    = ceil(Problem.FE/Problem.N);
    maxgen = ceil(Problem.maxFE/Problem.N);
    if size(temp1,1) > 2&&isempty(find(isnan(temp1)==true))&& gen <= round(1*maxgen) && isempty(genFlag)
        [net,genFlag] = TrainGrowingGasNet(temp1,net,params,Problem,genFlag);
    end
    
     %% Calculate the fitness of each solution
    [D_Dec,D_Pop,Fitness] = CalFitness(Population.objs,Population.decs);
    
    %% Environmental selection
    Next = Fitness < 1;
    if sum(Next) < N
        [~,Rank] = sort(Fitness);
        Next(Rank(1:N)) = true;
    elseif sum(Next) > N
        Del  = Truncation(Population(Next).objs,Population(Next).decs,sum(Next)-N,Problem);
        Temp = find(Next);
        Next(Temp(Del)) = false;
    end
    % Population for next generation
    Population = Population(Next);
    Fitness    = Fitness(Next);
    D_Dec      = D_Dec(Next);
    D_Pop      = D_Pop(Next);
    % Sort the population
    [Fitness,rank] = sort(Fitness);
    Population = Population(rank);
    D_Dec = D_Dec(rank);
    D_Pop = D_Pop(rank);
end

function Del = Truncation(PopObj,PopDec,K,Problem)
% Select part of the solutions by truncation

    %% Truncation
    Distance_Pop = pdist2(PopObj,PopObj);
    Distance_Pop(logical(eye(length(Distance_Pop)))) = inf;

    finitePopDist1 = Distance_Pop(isfinite(Distance_Pop)); % 获取非 inf 值
    minPopDist1 = min(finitePopDist1);
    maxPopDist1 = max(finitePopDist1);
    RangePopDist = maxPopDist1 - minPopDist1;
    if RangePopDist > 0
        Distance_Pop_normalized = (Distance_Pop - minPopDist1) / RangePopDist;
    else
        Distance_Pop_normalized = Distance_Pop;  % 如果最大值和最小值相同，则不需要归一化
    end
    
    Distance_Dec = pdist2(PopDec,PopDec);
    Distance_Dec(logical(eye(length(Distance_Dec)))) = inf;

    finitePopDist2 = Distance_Dec(isfinite(Distance_Dec)); % 获取非 inf 值
    minDecDist2 = min(finitePopDist2);
    maxDecDist2 = max(finitePopDist2);
    RangeDecDist = maxDecDist2 - minDecDist2;
    if RangeDecDist > 0
        Distance_Dec_normalized = (Distance_Dec - minDecDist2) / RangeDecDist;
    else
        Distance_Dec_normalized = Distance_Dec;  % 如果最大值和最小值相同，则不需要归一化
    end
    
    gen    = ceil(Problem.FE/Problem.N);
    maxgen = ceil(Problem.maxFE/Problem.N);
    pp=gen/maxgen;
    D = (1-pp)*Distance_Pop_normalized + pp*Distance_Dec_normalized;
    
    Del = false(1,size(PopObj,1));
    while sum(Del) < K
        Remain   = find(~Del);
        Temp     = sort(D(Remain,Remain),2);
        [~,Rank] = sortrows(Temp);
        Del(Remain(Rank(1))) = true;
    end
end
